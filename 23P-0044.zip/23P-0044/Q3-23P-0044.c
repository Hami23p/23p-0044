#include <stdio.h>

void parsePokerHands(char line[],char hand1[],char hand2[]);
int evaluateHand(char hand[]);
int compareHands(char hand1[],char hand2[]);

int main(){
    char hand1[14],hand2[14];

    printf("Enter hand for Player 1 (e.g., AC 2C 3C 4C 5C): ");
    scanf("%s %s %s %s %s",hand1,hand1+3,hand1+6,hand1+9,hand1+12);

    printf("Enter hand for Player 2 (e.g., 2H 3H 4H 5H 6H): ");
    scanf("%s %s %s %s %s",hand2,hand2+3,hand2+6,hand2+9,hand2+12);

    // Compare the hands
    
    int winner=compareHands(hand1, hand2);

    // Output the winner
    if (winner == 1){
        printf("Player 1 wins.\n");
    } 
	else if(winner==2){
        printf("Player 2 wins.\n");
    } 
	else{
        printf("It's a tie.\n");
    }

    return 0;
}

// Function to compare two poker hands and determine the winner
int compareHands(char hand1[],char hand2[]){
    // Evaluate the ranks of both hands
    int rank1=evaluateHand(hand1);
    
    int rank2=evaluateHand(hand2);

    // Compare the ranks to determine the winner
    if(rank1>rank2){
        return 1; // Player 1 wins
        
    }
	else if(rank1<rank2){
		
        return 2; // Player 2 wins
    } 
	else{
		
        return 0; // It's a tie
    }
}

// to evaluate the rank of a poker hand
int evaluateHand(char hand[]){
	
	
    int ranks[15]={0};
    
    int suits[4]={0}; // 0: Hearts, 1: Diamonds, 2: Clubs, 3: Spades

    int numericRanks[256]={0};
    
    numericRanks['A']=14;
    numericRanks['K']=13;
    numericRanks['Q']=12;
    numericRanks['J']=11;
    numericRanks['T'] = 10;
    for (char c='2';c<='9';++c){
    	
        numericRanks[c]=c-'0';
    }

    // Parse the hand and count the occurrences of each rank and suit
    for (int i=0;i<14;i+=3){
    	
        char rank=hand[i];
        char suit=hand[i+1];
        
        ranks[numericRanks[rank]]++;
        suits[suit - 'C']++; // Corrected index calculation
    }

    // Check for various hand ranks
    int isRoyalFlush=0;
    int isStraightFlush=0;
    int isFourOfAKind=0;
    int isFullHouse=0;
    int isFlush=0;
    int isStraight=0;
    int isThreeOfAKind= 0;
    int isTwoPair=0;
    int isOnePair=0;
    int isHighCard=0;

    // Royal Flush
    if (ranks[10] && ranks[11] && ranks[12] && ranks[13] && ranks[14] && suits[0]==5){
    	
        isRoyalFlush=1;
        
    }

    // Straight Flush
    for (int i=2;i<=10;++i){
    	
        if (ranks[i] && ranks[i+1] && ranks[i+2] && ranks[i+3] && ranks[i+4] && suits[0]==5){
        	
            isStraightFlush = 1;
            
            break;
        }
    }

    // Four of a Kind
    for (int i=2;i<=14;++i){
        if (ranks[i]==4){
        	
            isFourOfAKind=1;
            break;
        }
    }

    // Full House
    int hasThree=0;
    int hasPair=0;
    for (int i=2;i<=14;++i){
    	
        if(ranks[i]==3){
        	
            hasThree=1;
        }
		else if(ranks[i]==2)
	{
            hasPair=1;
        }
    }
    if(hasThree&&hasPair){
    	
        isFullHouse=1;
    }

    // Flush
    if(suits[0]==5|| suits[1]==5 || suits[2]==5 || suits[3]==5)
	{
		
        isFlush=1;
    }

    // Straight
    for (int i=2;i<=10;++i){
    	
        if(ranks[i] && ranks[i+1]&& ranks[i+2] && ranks[i+3] && ranks[i+4])
		{
            isStraight=1;
            break;
        }
    }

    // Three of a Kind
    for (int i=2;i<=14;++i){
    
        if(ranks[i]==3)
		{
			
            isThreeOfAKind=1;
            break;
        }
    }

    // Two Pair
    int numPairs=0;
    
    for(int i=2;i<=14;++i){
    	
        if(ranks[i]==2)
		{
			
            numPairs++;
        }
    }
    
    
    if(numPairs>=2)
	{
        isTwoPair=1;
    }

    // One Pair
    for(int i=2;i<=14;++i){
    	
        if(ranks[i]==2)
		{
            isOnePair=1;
            break;
        }
    }

    // High Card
    if (!isRoyalFlush && !isStraightFlush && !isFourOfAKind && !isFullHouse && !isFlush && !isStraight &&
        !isThreeOfAKind && !isTwoPair && !isOnePair)
		
	{
        	
        isHighCard=1;
    }

    // Determine the rank of the hand
    if (isRoyalFlush){
        return 10;
    } 
	else if(isStraightFlush){
        return 9;
    } 
    
	else if(isFourOfAKind){
        return 8;
    }
    
	else if(isFullHouse){
        return 7;
    } 
	else if(isFlush){
        return 6;
    }
	 
	else if(isStraight){
        return 5;
    }
    
	else if(isThreeOfAKind){
        return 4;
    } 
    
	else if(isTwoPair){
        return 3;
    } 
    
	else if(isOnePair){
        return 2;
    }
	 
	else if(isHighCard){
        return 1;
    }

    // If no rank is found, return 0 (High Card)

    return 0; // Dummy return value
}


