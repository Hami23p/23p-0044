#include <stdio.h>
#include<stdlib.h>
#include<time.h>
#define SIZE 20
#define LEN 4

int max;
char direction;
int start_i, start_j;

void max_product(int grid[SIZE][SIZE]) {
    max = 0;
    int i, j;
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            if (j < SIZE - LEN + 1) {
                // Horizontal
                int product = grid[i][j] * grid[i][j+1] * grid[i][j+2] * grid[i][j+3];
                if (product > max) {
                    max = product;
                    direction = 'H';
                    start_i = i;
                    start_j = j;
                }
            }
            if (i < SIZE - LEN + 1) {
                // Vertical
                int product = grid[i][j] * grid[i+1][j] * grid[i+2][j] * grid[i+3][j];
                if (product > max) {
                    max = product;
                    direction = 'V';
                    start_i = i;
                    start_j = j;
                }
            }
            if (i < SIZE - LEN + 1 && j < SIZE - LEN + 1) {
                // Diagonal down
                int product = grid[i][j] * grid[i+1][j+1] * grid[i+2][j+2] * grid[i+3][j+3];
                if (product > max) {
                    max = product;
                    direction = 'D';
                    start_i = i;
                    start_j = j;
                }
            }
            if (i >= LEN - 1 && j < SIZE - LEN+1) {
                // Diagonal up
                int product = grid[i][j] * grid[i-1][j+1] * grid[i-2][j+2] * grid[i-3][j+3];
                if (product > max) {
                    max = product;
                    direction = 'U';
                    start_i = i;
                    start_j = j;
                }
            }
        }
    }
}

void print_grid(int grid[SIZE][SIZE]) {
    int i, j;
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            if ((direction == 'H' && i == start_i && j >= start_j && j < start_j + LEN) ||
                (direction == 'V' && j == start_j && i >= start_i && i < start_i + LEN) ||
                (direction == 'D' && i >= start_i && i < start_i + LEN && j >= start_j && j < start_j + LEN) ||
                (direction == 'U' && i <= start_i && i > start_i - LEN && j >= start_j && j < start_j + LEN)) {
                printf("  * ");
            } 
			else{
                printf("%3d ", grid[i][j]);
            }
        }
        printf("\n");
    }
}

int main(){
    int grid[SIZE][SIZE];
    
    srand(time(NULL));
    
    int i,j;
    
    for (i=0;i<SIZE;i++){
    	
    	
        for (j=0;j<SIZE;j++){
            grid[i][j]=rand()%100;  
        }
    }

    for (i=0;i<SIZE;i++){
    	
        for (j=0;j<SIZE;j++){
        	
            printf("%3d ",grid[i][j]);
        }
        printf("\n");
    }
    
    max_product(grid);
    
    printf("Max product: %d,Direction: %c,Start position:(%d,%d)\n",max,direction,start_i,start_j);

    print_grid(grid);

    return 0;
}

