#include <stdio.h>

// Function to calculate the Collatz sequence length for a given starting number
int collatzLength(int num){
    int length = 1;// Initialize length to 1 (counting the starting number)
    
    
    while (num!=1)
	{
        if (num%2==0) {
            num/=2; //If even,divide by 2
        } else {
            num = 3 * num + 1; //If odd,multiply by 3 and add 1
        }
        length++; //Increment the sequence length
    }
    return length;
}

// Function to find the starting number under N with the longest Collatz sequence
int findLongestCollatz(int N){
	
    int maxLen=0; // Initialize maximum length
    
    int maxStart=0; // Initialize starting number with longest sequence

    for (int i=1;i<=N;i++){
    	
        int len=collatzLength(i); // Calculate sequence length for current number
        
        if(len>maxLen)
		{
            maxLen = len; // Update maximum length
            maxStart = i; // Update starting number with longest sequence
        }
    }

    return maxStart;
}

int main() {
    int N;
    printf("Enter the upper limit N: ");
    scanf("%d", &N);

    int longestStart = findLongestCollatz(N);
    
    int longestLen = collatzLength(longestStart);

    printf("Starting number with the longest Collatz sequence: %d\n",longestStart);
    printf("Length of the sequence: %d\n",longestLen);

    return 0;
}

